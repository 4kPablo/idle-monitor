"use client"

import { useState, useEffect, useCallback } from "react"
import AnalogClock from "@/components/analog-clock"
import MonthCalendar from "@/components/month-calendar"
import WeatherWidget from "@/components/weather-widget"
import TechNews from "@/components/tech-news"
import ProgressRings from "@/components/progress-rings"
import ParticlesBg from "@/components/particles-bg"
import PomodoroTimer from "@/components/pomodoro-timer"
import AmbientSounds from "@/components/ambient-sounds"
import HourlyChime from "@/components/hourly-chime"
import DraggableWidget from "@/components/draggable-widget"
import { getWidgetLayout, saveWidgetLayout, moveWidget } from "@/lib/widget-store"

const widgetComponents = {
  "analog-clock": { component: AnalogClock, props: (state) => ({ time: state.currentTime }) },
  "calendar": { component: MonthCalendar, props: (state) => ({ currentDate: state.currentTime, pomodoroRefresh: state.pomodoroRefresh }) },
  "ambient": { component: AmbientSounds, props: () => ({}) },
  "weather": { component: WeatherWidget, props: () => ({}) },
  "pomodoro": { component: PomodoroTimer, props: (state) => ({ onPomodoroComplete: state.handlePomodoroComplete }) },
  "tech-news": { component: TechNews, props: () => ({}) },
  "progress": { component: ProgressRings, props: (state) => ({ currentTime: state.currentTime }) },
}

export default function HomePage() {
  const [currentTime, setCurrentTime] = useState(new Date())
  const [pomodoroRefresh, setPomodoroRefresh] = useState(0)
  const [hourlyPulse, setHourlyPulse] = useState(false)
  const [layout, setLayout] = useState({ left: [], right: [] })
  const [draggingWidget, setDraggingWidget] = useState(null)
  const [mounted, setMounted] = useState(false)

  const currentHour = currentTime.getHours()
  const isNightMode = currentHour >= 0 && currentHour < 7

  useEffect(() => {
    setMounted(true)
    setLayout(getWidgetLayout())
  }, [])

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date())
    }, 1000)
    return () => clearInterval(timer)
  }, [])

  const handlePomodoroComplete = useCallback(() => {
    setPomodoroRefresh((prev) => prev + 1)
  }, [])

  const handleHourlyChime = useCallback(() => {
    setHourlyPulse(true)
    setTimeout(() => setHourlyPulse(false), 2000)
  }, [])

  const handleDrop = useCallback((targetColumn) => (draggedWidgetId) => {
    const sourceColumn = layout.left.includes(draggedWidgetId) ? "left" : "right"
    if (sourceColumn === targetColumn) return
    
    const newLayout = moveWidget(draggedWidgetId, sourceColumn, targetColumn, layout)
    setLayout(newLayout)
    saveWidgetLayout(newLayout)
  }, [layout])

  const hours = currentTime.getHours().toString().padStart(2, "0")
  const minutes = currentTime.getMinutes().toString().padStart(2, "0")
  const dateOptions = {
    weekday: "long",
    month: "long",
    day: "numeric",
  }
  const formattedDate = currentTime.toLocaleDateString("es-ES", dateOptions)

  const cardClass = isNightMode 
    ? "p-4 bg-black/60 backdrop-blur-sm border-border/50 transition-colors duration-500" 
    : "p-4 bg-card/80 backdrop-blur-sm border-border transition-colors duration-500"

  const state = {
    currentTime,
    pomodoroRefresh,
    handlePomodoroComplete,
  }

  const renderWidget = (widgetId, index, column) => {
    const widgetConfig = widgetComponents[widgetId]
    if (!widgetConfig) return null
    
    const Component = widgetConfig.component
    const props = widgetConfig.props(state)
    
    return (
      <DraggableWidget
        key={widgetId}
        id={widgetId}
        cardClass={cardClass}
        onDragStart={setDraggingWidget}
        onDragEnd={() => setDraggingWidget(null)}
        onDrop={handleDrop(column)}
        isDragging={draggingWidget === widgetId}
        animationDelay={100 + index * 50}
      >
        <Component {...props} />
      </DraggableWidget>
    )
  }

  if (!mounted) {
    return (
      <div className="min-h-screen animated-bg flex items-center justify-center">
        <div className="text-primary text-2xl font-mono animate-pulse">Cargando...</div>
      </div>
    )
  }

  return (
    <div className={`min-h-screen p-6 flex items-center justify-center relative transition-colors duration-1000 ${isNightMode ? "bg-black" : "animated-bg"}`}>
      <ParticlesBg />
      <HourlyChime currentTime={currentTime} isNightMode={isNightMode} onChime={handleHourlyChime} />
      
      <div className="w-full max-w-7xl relative z-10 flex gap-6 items-center">
        {/* Columna izquierda */}
        <div 
          className={`w-72 flex-shrink-0 space-y-4 transition-all duration-300 ${
            draggingWidget && !layout.left.includes(draggingWidget) ? "ring-2 ring-primary/30 ring-offset-4 ring-offset-transparent rounded-xl" : ""
          }`}
          onDragOver={(e) => e.preventDefault()}
          onDrop={(e) => {
            e.preventDefault()
            const widgetId = e.dataTransfer.getData("widgetId")
            if (!layout.left.includes(widgetId)) {
              handleDrop("left")(widgetId)
            }
          }}
        >
          {layout.left.map((widgetId, index) => renderWidget(widgetId, index, "left"))}
        </div>

        {/* Centro - Reloj principal grande */}
        <div className="flex-1 flex flex-col items-center justify-center">
          <div className="text-center">
            <div 
              className={`font-mono text-9xl font-bold tracking-tight mb-3 transition-all duration-500 ${
                hourlyPulse 
                  ? "text-accent scale-105 drop-shadow-[0_0_30px_oklch(0.7_0.2_180)]" 
                  : "text-primary"
              }`}
            >
              {hours}:{minutes}
            </div>
            <div className="text-2xl text-muted-foreground capitalize transition-all duration-300">
              {formattedDate}
            </div>
          </div>
        </div>

        {/* Columna derecha */}
        <div 
          className={`w-72 flex-shrink-0 space-y-4 transition-all duration-300 ${
            draggingWidget && !layout.right.includes(draggingWidget) ? "ring-2 ring-primary/30 ring-offset-4 ring-offset-transparent rounded-xl" : ""
          }`}
          onDragOver={(e) => e.preventDefault()}
          onDrop={(e) => {
            e.preventDefault()
            const widgetId = e.dataTransfer.getData("widgetId")
            if (!layout.right.includes(widgetId)) {
              handleDrop("right")(widgetId)
            }
          }}
        >
          {layout.right.map((widgetId, index) => renderWidget(widgetId, index, "right"))}
        </div>
      </div>
    </div>
  )
}
