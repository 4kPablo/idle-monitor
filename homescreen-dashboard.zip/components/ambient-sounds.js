"use client"

import { useState, useRef, useEffect, useCallback } from "react"
import { Volume2, VolumeX, Coffee, Waves, CloudRain, Wind, TreePine } from "lucide-react"
import { Slider } from "@/components/ui/slider"

const sounds = [
  { 
    id: "brown", 
    label: "Ruido Marron", 
    icon: Waves,
    type: "noise",
    noiseType: "brown"
  },
  { 
    id: "rain", 
    label: "Lluvia", 
    icon: CloudRain,
    type: "noise",
    noiseType: "rain"
  },
  { 
    id: "cafe", 
    label: "Cafeteria", 
    icon: Coffee,
    type: "noise",
    noiseType: "cafe"
  },
  { 
    id: "wind", 
    label: "Viento", 
    icon: Wind,
    type: "noise",
    noiseType: "wind"
  },
  { 
    id: "forest", 
    label: "Bosque", 
    icon: TreePine,
    type: "noise",
    noiseType: "forest"
  },
]

export default function AmbientSounds() {
  const [activeSound, setActiveSound] = useState(null)
  const [volume, setVolume] = useState(0.5)
  const [isPlaying, setIsPlaying] = useState(false)
  const audioContextRef = useRef(null)
  const noiseNodeRef = useRef(null)
  const gainNodeRef = useRef(null)

  useEffect(() => {
    return () => {
      stopAllSounds()
    }
  }, [])

  const createNoise = useCallback((audioContext, type) => {
    const bufferSize = 2 * audioContext.sampleRate
    const noiseBuffer = audioContext.createBuffer(2, bufferSize, audioContext.sampleRate)
    
    for (let channel = 0; channel < 2; channel++) {
      const output = noiseBuffer.getChannelData(channel)
      let lastOut = 0.0
      
      for (let i = 0; i < bufferSize; i++) {
        const white = Math.random() * 2 - 1
        
        switch (type) {
          case "brown":
            output[i] = (lastOut + 0.02 * white) / 1.02
            lastOut = output[i]
            output[i] *= 3.5
            break
          case "rain":
            // Rain-like noise: filtered white noise with occasional peaks
            const rainFilter = (lastOut + 0.05 * white) / 1.05
            lastOut = rainFilter
            output[i] = rainFilter * 2.5 + (Math.random() > 0.998 ? white * 0.3 : 0)
            break
          case "cafe":
            // Cafe ambience: low rumble with occasional murmurs
            output[i] = (lastOut + 0.01 * white) / 1.01
            lastOut = output[i]
            output[i] *= 2 + (Math.sin(i / 5000) * 0.5)
            break
          case "wind":
            // Wind: slowly modulating brown noise
            output[i] = (lastOut + 0.03 * white) / 1.03
            lastOut = output[i]
            output[i] *= 2.5 * (0.7 + 0.3 * Math.sin(i / 10000))
            break
          case "forest":
            // Forest: mix of wind and bird-like chirps
            output[i] = (lastOut + 0.025 * white) / 1.025
            lastOut = output[i]
            output[i] *= 2 + (Math.random() > 0.9995 ? Math.sin(i * 0.1) * 0.2 : 0)
            break
          default:
            output[i] = (lastOut + 0.02 * white) / 1.02
            lastOut = output[i]
            output[i] *= 3.5
        }
      }
    }
    
    const noiseSource = audioContext.createBufferSource()
    noiseSource.buffer = noiseBuffer
    noiseSource.loop = true
    
    return noiseSource
  }, [])

  const stopAllSounds = useCallback(() => {
    if (noiseNodeRef.current) {
      try {
        noiseNodeRef.current.stop()
      } catch (e) {}
      noiseNodeRef.current = null
    }
    if (audioContextRef.current) {
      try {
        audioContextRef.current.close()
      } catch (e) {}
      audioContextRef.current = null
    }
    gainNodeRef.current = null
  }, [])

  const playSound = useCallback(async (sound) => {
    if (activeSound === sound.id) {
      stopAllSounds()
      setActiveSound(null)
      setIsPlaying(false)
      return
    }

    stopAllSounds()

    try {
      audioContextRef.current = new (window.AudioContext || window.webkitAudioContext)()
      gainNodeRef.current = audioContextRef.current.createGain()
      gainNodeRef.current.gain.value = volume
      gainNodeRef.current.connect(audioContextRef.current.destination)
      
      noiseNodeRef.current = createNoise(audioContextRef.current, sound.noiseType)
      noiseNodeRef.current.connect(gainNodeRef.current)
      noiseNodeRef.current.start()
      
      setActiveSound(sound.id)
      setIsPlaying(true)
    } catch (e) {
      console.error("Error playing sound:", e)
    }
  }, [activeSound, volume, createNoise, stopAllSounds])

  const handleVolumeChange = useCallback((newVolume) => {
    const vol = newVolume[0]
    setVolume(vol)
    if (gainNodeRef.current) {
      gainNodeRef.current.gain.value = vol
    }
  }, [])

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          {isPlaying ? (
            <Volume2 className="w-4 h-4 text-accent" />
          ) : (
            <VolumeX className="w-4 h-4 text-muted-foreground" />
          )}
          <h3 className="text-sm font-medium text-muted-foreground">Ambiente</h3>
        </div>
      </div>
      
      <div className="grid grid-cols-5 gap-1.5">
        {sounds.map((sound) => {
          const Icon = sound.icon
          const isActive = activeSound === sound.id
          return (
            <button
              key={sound.id}
              type="button"
              onClick={() => playSound(sound)}
              className={`
                flex flex-col items-center justify-center p-2 rounded-lg transition-all duration-200 cursor-pointer
                ${isActive 
                  ? "bg-primary/20 text-primary scale-105" 
                  : "bg-secondary/30 text-muted-foreground hover:bg-secondary/50 hover:text-foreground hover:scale-105"
                }
              `}
              title={sound.label}
            >
              <Icon className="w-4 h-4" />
            </button>
          )
        })}
      </div>

      <div className="flex items-center gap-3 pt-1">
        <VolumeX className="w-3 h-3 text-muted-foreground" />
        <Slider
          value={[volume]}
          onValueChange={handleVolumeChange}
          max={1}
          step={0.01}
          className="flex-1 cursor-pointer"
        />
        <Volume2 className="w-3 h-3 text-muted-foreground" />
      </div>
    </div>
  )
}
