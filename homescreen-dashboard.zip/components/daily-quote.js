"use client"

import { Sparkles } from "lucide-react"

export default function DailyQuote() {
  const quotes = [
    {
      text: "El éxito no es la clave de la felicidad. La felicidad es la clave del éxito.",
      author: "Albert Schweitzer",
    },
    {
      text: "No cuentes los días, haz que los días cuenten.",
      author: "Muhammad Ali",
    },
    {
      text: "La única forma de hacer un gran trabajo es amar lo que haces.",
      author: "Steve Jobs",
    },
    {
      text: "El futuro pertenece a quienes creen en la belleza de sus sueños.",
      author: "Eleanor Roosevelt",
    },
  ]

  const today = new Date()
  const dayOfYear = Math.floor((today - new Date(today.getFullYear(), 0, 0)) / 1000 / 60 / 60 / 24)
  const quote = quotes[dayOfYear % quotes.length]

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Sparkles className="w-5 h-5 text-accent animate-pulse-glow" />
        <h3 className="text-sm font-medium text-muted-foreground">Frase del día</h3>
      </div>
      <blockquote className="space-y-3">
        <p className="text-lg leading-relaxed text-balance">{quote.text}</p>
        <footer className="text-sm text-muted-foreground">— {quote.author}</footer>
      </blockquote>
    </div>
  )
}
