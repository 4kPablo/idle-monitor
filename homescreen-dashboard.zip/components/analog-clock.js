"use client"

export default function AnalogClock({ time }) {
  const hours = time.getHours() % 12
  const minutes = time.getMinutes()
  const seconds = time.getSeconds()

  const hourAngle = hours * 30 + minutes * 0.5
  const minuteAngle = minutes * 6 + seconds * 0.1
  const secondAngle = seconds * 6

  const size = 176
  const center = size / 2
  const outerRadius = size / 2 - 4

  return (
    <div className="flex flex-col items-center">
      <svg width={size} height={size} className="drop-shadow-sm">
        {/* Circulo exterior */}
        <circle
          cx={center}
          cy={center}
          r={outerRadius}
          fill="oklch(0.14 0.01 250)"
          stroke="oklch(0.25 0.02 250)"
          strokeWidth="1"
        />

        {/* Subdivisiones - 60 marcas en el borde */}
        {Array.from({ length: 60 }).map((_, i) => {
          const angle = (i * 6 - 90) * (Math.PI / 180)
          const isHour = i % 5 === 0
          const outerR = outerRadius - 2
          const innerR = isHour ? outerRadius - 12 : outerRadius - 6
          
          const x1 = center + outerR * Math.cos(angle)
          const y1 = center + outerR * Math.sin(angle)
          const x2 = center + innerR * Math.cos(angle)
          const y2 = center + innerR * Math.sin(angle)

          return (
            <line
              key={`tick-${i}`}
              x1={x1}
              y1={y1}
              x2={x2}
              y2={y2}
              stroke={isHour ? "oklch(0.6 0.08 220)" : "oklch(0.35 0.02 250)"}
              strokeWidth={isHour ? 2 : 1}
              strokeLinecap="round"
            />
          )
        })}

        {/* Numeros de las horas */}
        {[12, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11].map((num, i) => {
          const angle = (i * 30 - 90) * (Math.PI / 180)
          const r = outerRadius - 24
          const x = center + r * Math.cos(angle)
          const y = center + r * Math.sin(angle)

          return (
            <text
              key={num}
              x={x}
              y={y}
              textAnchor="middle"
              dominantBaseline="central"
              className="fill-muted-foreground text-xs font-medium"
              style={{ fontSize: "11px" }}
            >
              {num}
            </text>
          )
        })}

        {/* Manecilla de hora */}
        <line
          x1={center}
          y1={center}
          x2={center + 38 * Math.cos((hourAngle - 90) * (Math.PI / 180))}
          y2={center + 38 * Math.sin((hourAngle - 90) * (Math.PI / 180))}
          stroke="oklch(0.65 0.18 220)"
          strokeWidth="3"
          strokeLinecap="round"
        />

        {/* Manecilla de minutos */}
        <line
          x1={center}
          y1={center}
          x2={center + 52 * Math.cos((minuteAngle - 90) * (Math.PI / 180))}
          y2={center + 52 * Math.sin((minuteAngle - 90) * (Math.PI / 180))}
          stroke="oklch(0.70 0.20 180)"
          strokeWidth="2"
          strokeLinecap="round"
        />

        {/* Manecilla de segundos */}
        <line
          x1={center}
          y1={center}
          x2={center + 58 * Math.cos((secondAngle - 90) * (Math.PI / 180))}
          y2={center + 58 * Math.sin((secondAngle - 90) * (Math.PI / 180))}
          stroke="oklch(0.72 0.18 160)"
          strokeWidth="1"
          strokeLinecap="round"
        />

        {/* Centro */}
        <circle
          cx={center}
          cy={center}
          r="4"
          fill="oklch(0.65 0.18 220)"
        />
      </svg>
    </div>
  )
}
