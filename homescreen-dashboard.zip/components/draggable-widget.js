"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { GripVertical } from "lucide-react"

export default function DraggableWidget({ 
  id, 
  children, 
  cardClass, 
  onDragStart, 
  onDragEnd, 
  onDrop, 
  isDragging,
  animationDelay 
}) {
  const [isOver, setIsOver] = useState(false)

  const handleDragStart = (e) => {
    e.dataTransfer.setData("widgetId", id)
    onDragStart?.(id)
  }

  const handleDragEnd = () => {
    onDragEnd?.()
  }

  const handleDragOver = (e) => {
    e.preventDefault()
    setIsOver(true)
  }

  const handleDragLeave = () => {
    setIsOver(false)
  }

  const handleDrop = (e) => {
    e.preventDefault()
    setIsOver(false)
    const widgetId = e.dataTransfer.getData("widgetId")
    onDrop?.(widgetId)
  }

  return (
    <Card
      draggable
      onDragStart={handleDragStart}
      onDragEnd={handleDragEnd}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      className={`
        ${cardClass} 
        relative group
        transition-all duration-300 ease-out
        ${isDragging ? "opacity-50 scale-95" : "opacity-100 scale-100"}
        ${isOver ? "ring-2 ring-primary/50 scale-[1.02]" : ""}
        animate-in fade-in slide-in-from-bottom-2 duration-500
      `}
      style={{ animationDelay: `${animationDelay}ms` }}
    >
      <div 
        className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200 cursor-grab active:cursor-grabbing p-1 rounded hover:bg-secondary/50"
        title="Arrastrar para mover"
      >
        <GripVertical className="w-4 h-4 text-muted-foreground" />
      </div>
      {children}
    </Card>
  )
}
